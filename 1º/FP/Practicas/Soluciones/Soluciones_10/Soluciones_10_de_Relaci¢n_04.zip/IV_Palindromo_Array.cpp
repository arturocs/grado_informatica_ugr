/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 4
// EJERCICIO 4
//
/*	
	Programa que lee un n�mero indeterminado de caracteres (la lectura 
	termina cuando se introduce un '*'), los guarda en un vector y dice 
	si el vector es un pal�ndromo, es decir, que se lee igual de izquierda 
	a derecha que de derecha a izquierda.
	
	Presentamos dos versi�nes: 
		1) La primera analiza el vector "tal cual es".
		2) La segunda no considera los separadores y no diferencia 
		   entre may�sculas y min�sculas.
*/
/***************************************************************************/

#include <iostream>
#include <cctype>
using namespace std;


int main (void)
{		
	// Vector de datos
	
	const int TAMANIO = 100; 
	char vector[TAMANIO];
	
	int total_utilizados = 0;	
	
	
	// Lectura de datos 
	
	char caracter;
	
	caracter = cin.get();	// Lectura adelantada
	
	while ((caracter != '*') && (total_utilizados<TAMANIO)) {
		vector[total_utilizados] = caracter;
		total_utilizados++;
	
		caracter = cin.get(); // Lectura adelantada
	}
	
	
	// C�lculos
	
	int izda, dcha; // Para recorrer el vector por los dos extremos 
		
	// VERSI�N 1: El vector se procesa "tal cual"
	
	bool es_palindromo1 = true;
	
	izda = 0;	// Para recorrer de izqierda a derecha
	dcha = total_utilizados - 1; // Para recorrer de derecha a izquierda

	while ((izda < dcha) && es_palindromo1) {

		if (vector[izda] != vector[dcha])
		
			es_palindromo1 = false; // terminar
			
		else {	// seguir buscando
			izda++; // posici�n siguiente
			dcha--;	// posici�n anterior
		}

	} // while ((izda < dcha) && es_palindromo)


	// VERSI�N 2: no se consideran separadores ni se diferencian may�sculas 
	// y min�sculas
	
	bool es_palindromo2 = true;

	izda = 0;	// Para recorrer de izqierda a derecha
	dcha = total_utilizados - 1; // Para recorrer de derecha a izquierda

	while ((izda < dcha) && es_palindromo2) {

		while ((isspace(vector[izda])) && (izda < dcha))  izda++;
		while ((isspace(vector[dcha])) && (izda < dcha))  dcha--;
		
		if (izda < dcha) {
		
			if (toupper(vector[izda]) != toupper(vector[dcha]))
	
				es_palindromo2 = false; // terminar
	
			else {	// seguir buscando
				izda++; // posici�n siguiente
				dcha--;	// posici�n anterior
			}
		}

	} // while ((izda < dcha) && es_palindromo)
	
	// Mostrar Resultado
	
	cout << "Seg�n versi�n 1: "; 
	if (es_palindromo1) cout << "Es un pal�ndromo";
	else cout << "No es un pal�ndromo";
	cout << endl;
	
	cout << "Seg�n versi�n 2: "; 
	if (es_palindromo2) cout << "Es un pal�ndromo";
	else cout << "No es un pal�ndromo";
	cout << endl;
	
	return (0);
}
