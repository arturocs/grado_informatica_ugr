/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 4
// EJERCICIO 3
//
/*	
	Programa que lee un n�mero indeterminado de caracteres (la lectura 
	termina cuando se introduce un '*') y muestra el n�mero total 
	de apariciones cada letra.

	* Para poder leer un espacio en blanco NO puede emplear cin >> caracter, 
	  sino caracter = cin.get(). Cada vez que se ejecuta cin.get() se lee un 
	  car�cter (incluido el espacio en blanco) desde cin.
	* Para el c�mputo se consideran iguales una letra y la may�scula 
	  corespondiente.
	* No se contabilizan d�gitos, separadores u otros caracteres.
*/
/***************************************************************************/

#include <iostream>
using namespace std;
 
/***************************************************************************/

int main (void)
{	
	// Vector de datos
	
	const int NUM_LETRAS = 'Z'-'A'+1; 
	int contador[NUM_LETRAS];
	
	// Inicializar contadores 
	
	for (int pos=0; pos<NUM_LETRAS; pos++) 
		contador[pos] = 0;

	int cont_total = 0; // Contador de caracteres leidos 
	
	
	// Lectura de datos 
	
	bool sigo = true; 
	char caracter;
	
	caracter = cin.get();
	
	while ( caracter != '*') {
	
		cont_total++;
		
		if (isalpha(caracter))	{
		
			caracter = toupper(caracter);
			contador[caracter-'A']++;
		}
	
		caracter = cin.get();
	}

	// Presentaci�n de resultados
		 	 
	cout << endl;

	int cont_letras = 0; // Contabilizamos el n�mero total de letras leidas 
	
	for (int pos=0; pos<NUM_LETRAS; pos++) {
		
		char letra = 'A' + pos;
	
		// Solo procesamos si hay alguna letra	
				
		if (contador[pos] != 0) {
			cout << letra << " --> " << contador[pos] << endl; 
			cont_letras += contador[pos];
		}
	}

	cout << endl;	
	cout << "Se escribieron " << cont_letras << " letras ";
	cout << "de un total de " << cont_total << " caracteres." << endl;	
	cout << endl << endl;

	return (0);
}
