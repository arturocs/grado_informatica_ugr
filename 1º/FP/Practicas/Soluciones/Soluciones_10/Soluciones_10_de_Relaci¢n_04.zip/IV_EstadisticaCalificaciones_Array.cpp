/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 4
// EJERCICIO 1 
//
/*	
	Este programa realiza un estudio estudio sobre las calificaciones de 
	una clase, limitado a un n�mero m�ximo de 100 alumnos.

	El programa lee en primer lugar el n�mero de alumnos y a continuaci�n
	lee y almacena las calificaciones. Seguidamente pide el n�mero
	de intervalos, "n", para realizar el estudio y finalmente calcula
	cu�ntas calificaciones hay en cada intervalo y muestra los resultados.

	Por ejemplo, si n=10  los intervalos son: [0,1), [1,2), ... , [9,10]
				 si n=2 los intervalos son: [0,5), [5,10].

*/
/***************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

/***************************************************************************/
// Devuelve la posici�n (el n�mero de intervalo) que le corresponde a la 
// calificaci�n "una_nota" si se consideran "num_intervalos" intervalos 
// de igual longitud entre 0.0 y 10.0

int Posicion (double una_nota, int num_intervalos)
{
	double anchura_intervalo = 10.0 / num_intervalos; 
 
 	int intervalo = 0; 
 	
	// Extremos del primer intervalo
	double izda = 0.0; 
	double dcha = anchura_intervalo; 
	
	while (izda <= una_nota) {
		
		intervalo++;
		
		// Actualizar extremos para el siguiente intervalo
		izda = dcha;
		dcha = izda + anchura_intervalo;
	}
		
	// ��Debe devolver uno menos!!
	return (intervalo-1);
}

/***************************************************************************/

int main (void)
{
	
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 
	
	// Vector de notas
	
	const int MAX_ALUMNOS = 100; 
	double notas[MAX_ALUMNOS];
	int total_utilizados_notas = 0;
	
	// Vector de contadores: cada casilla corresponde a un intervalo
	
	const int MAX_INTERVALOS = 10; 
	int num_notas[MAX_INTERVALOS];
	
	
	// Leer y filtrar el n�mero de alumnos

	int num_alumnos; 

	do {
		cout << "Num. de alumnos: ";
		cin >> num_alumnos;
	} while ((num_alumnos<=0) || (num_alumnos>MAX_ALUMNOS));
	cout << endl; 

	// Rellenar el vector "notas"
		
	for (int num_nota=0; num_nota<num_alumnos; num_nota++) {

		// Leer y filtrar cada nota

		double una_nota;
			
		do {
			cout << "Nota num. " << setw(3) << num_nota+1 << " = ";
			cin >> una_nota;
		} while ((una_nota<0.0) || (una_nota>10.0));
				
		// Guardar la nota e incrementar el contador de notas 
		notas[num_nota] = una_nota;
		total_utilizados_notas++;
	}
	cout << endl; 

	// Leer y filtrar el n�mero de intervalos
	
 	int num_intervalos;
 	
 	do {
		cout << "Num. de intervalos = ";
		cin >> num_intervalos;
	} while ((num_intervalos<1) || (num_intervalos>MAX_INTERVALOS));
	cout << endl; 	
 	
 	
	// MUY IMPORTANTE: inicializar los contadores a cero
	
	for (int intervalo=0; intervalo<num_intervalos; intervalo++)
		num_notas[intervalo] = 0;	
 	
 	// Para cada nota, calcular qu� posici�n (intervalo) le corresponde 
 	// e incrementar el contador asociado a ese intervalo
 	
	for (int num_nota=0; num_nota<num_alumnos; num_nota++) {
	
		int posicion = Posicion (notas[num_nota], num_intervalos);
		num_notas[posicion]++;
 	} 	

	// Mostrar los resultados 
	
	double anchura_intervalo = 10.0 / num_intervalos; 
	double extremo_izda;
	double extremo_dcha;
		 
	for (int intervalo=0; intervalo<num_intervalos-1; intervalo++) {

		extremo_izda = intervalo * anchura_intervalo;
		extremo_dcha  = extremo_izda + anchura_intervalo; 
	
		cout << "Notas en el intervalo ";  
		cout <<  "[" <<  setw(5) << setprecision(2) << extremo_izda << ", " 
	     	 << setw(5) << setprecision(2) << extremo_dcha << ") = ";  
		cout << setw(3) << num_notas[intervalo] << endl;	
	}
	
	// El �ltimo intervalo se muestra de manera especial porque el caracter 
	// de cierre es ] y no ) 
	
	extremo_izda = (num_intervalos-1) * anchura_intervalo;
	extremo_dcha  = extremo_izda + anchura_intervalo; 

	cout << "Notas en el intervalo ";  
	cout <<  "[" <<  setw(5) << setprecision(2) << extremo_izda << ", " 
	     << setw(5) << setprecision(2) << extremo_dcha << "] = ";  
	cout << setw(3) << num_notas[num_intervalos-1] << endl;	
 	cout << endl; 
 	
	return (0);
}
