/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 4
// EJERCICIO 2
//
/*	
	Programa que lee un n�mero indeterminado de n�meros positivos
	(termina la lectura cuando se introduce un negativo) aunque nunca leer� 
	m�s de 50. Conforme los lee, los va almacenando en un vector.

	A continuaci�n elimina del vector los valores repetidos, dejando 
	una sola copia. No se dejan huecos en el vector y todos los n�meros 
	quedan agrupados en las posiciones m�s bajas del vector.

	Se implementan dos versiones del borrado, que se corresponden a 
	las propuestas de los apartados b y c del problema 11.
*/
/***************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

/***************************************************************************/

int main (void)
{
	
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 
	
	// Vector de datos
	
	const int MAX_DATOS = 50; 
	int datos[MAX_DATOS];
	
	int total_utilizados = 0;	

	// Lectura de los datos 
	
	bool sigo = true; 
	int dato; 
	
	cin >> dato;
	
	while ((dato>=0) && (sigo)) {

		datos[total_utilizados]	= dato;
		total_utilizados++;

		if (total_utilizados==MAX_DATOS) 
			sigo = false;
		else 
			cin >> dato;
	}

	// Se muestran los datos originales
	
	cout << endl;	
 	cout << "Datos originales: " << "(" << setw(3) 
	 	 << total_utilizados << " datos): " << endl;	
	 	 
	for (int i=0; i<total_utilizados; i++) 
		cout << setw(3) << datos[i] << "  "; 
	cout << endl;
	

	// Copia de los datos originales en dos vectores para trabajar sobre 
	// los nuevos vectores y no perder los datos originales
	
	int copia1_datos[MAX_DATOS];
	int total_utilizados_copia1 = 0;	

	int copia2_datos[MAX_DATOS];
	int total_utilizados_copia2 = 0;	

	for (int i=0; i<total_utilizados; i++) 
		copia1_datos[i] = datos[i];
	 total_utilizados_copia1 = total_utilizados;

	for (int i=0; i<total_utilizados; i++) 
		copia2_datos[i] = datos[i];
	 total_utilizados_copia2 = total_utilizados;

 	/***********************************************************************/
 	
	// Se muestran los datos del vector copia (1) antes de procesarlos 
	
	cout << endl;	
 	cout << "Copia 1 antes de eliminar repetidos con algoritmo ineficiente"
	     << " (" << setw(3) << total_utilizados_copia1 << " datos):" << endl;	

	for (int i=0; i<total_utilizados_copia1; i++) 
		cout << setw(3) << copia1_datos[i] << "  "; 
	cout << endl;
 
 	// Borrado con desplazamiento
 	
 	// Empezamos a buscar repetidos desde la posici�n "pos_del_buscado" 
	// hacia arriba. Damos por hecho que los que est�n por debajo no est�n 
	// repetidos. Cuando "pos_del_buscado"=1 solo hay uno por debajo, 
	// el de la posici�n 0 y evidentemente no est� repetido (solo hay 
	// uno por debajo del que ocupa la posici�n "pos_del_buscado"). 
 	
 	int pos_del_buscado = 1;
		
	while (pos_del_buscado < total_utilizados_copia1) {

		int valor_buscado = copia1_datos[pos_del_buscado];

		// Busco "valor_buscado" (el de "pos_del_buscado") en el 
		// subvector izquierdo (posiciones: 0 hasta "pos_del_buscado"-1)
		
  		int pos = 0;
		bool encontrado = false;
    
		while ((pos < pos_del_buscado) && (!encontrado))

			if (copia1_datos[pos] == valor_buscado) 
				encontrado = true; //�xito: terminar
			else
				pos++; // Siguiente posici�n

		if (encontrado) {
		
			int tope = total_utilizados_copia1-1; // posici�n del �ltimo 
    
    		// Desplazar hacia la izquierda los valores que est�n a 
    		// la derecha del que ocupa la posici�n "pos_del_buscado"
    		
			for (int i=pos_del_buscado ; i < tope ; i++)
				copia1_datos[i] = copia1_datos[i+1];  
    
			total_utilizados_copia1--;  // Ya hay uno menos
		}
		else
			pos_del_buscado++; // Procesar el suguiente

	} // while (pos_del_buscado < total_utilizados_copia1)
		
			
	// Se muestran los datos del vector copia (1) despu�s de procesarlos 
	
	cout << endl;	
 	cout << "Copia 1 despu�s de eliminar repetidos con algoritmo ineficiente"
	     << " (" << setw(3) << total_utilizados_copia1 << " datos):" << endl;

	for (int i=0; i<total_utilizados_copia1; i++) 
		cout << setw(3) << copia1_datos[i] << "  "; 
	cout << endl;
	
 	
 	
 	/***********************************************************************/
 
	// Se muestran los datos del vector copia (2) antes de procesarlos 
	
 	cout << endl;	
	cout << "Copia 2 antes de eliminar repetidos con algoritmo eficiente" 
	     << " (" << setw(3) << total_utilizados_copia2 << "datos):" << endl;
	     
	for (int i=0; i<total_utilizados_copia2; i++) 
		cout << setw(3) << copia2_datos[i] << "  "; 
	cout << endl;
	
	
	// Borrado manteniendo posiciones de lectura y escritura

	// Las componentes no repetidas se almacenan al principio del vector
	// Empleamos apuntadores para las posiciones de lectura y escritura. 
	/*
		Sea "pos_escritura"=1
		Recorrer las componentes "v[pos_lectura]" con "pos_lectura">0
			Si la componente "v[pos_lectura]" NO se encuentra entre 
			las posiciones 0 y "pos_escritura",
				Colocamos dicha componente en "pos_escritura".    
	*/				
					
	int pos_escritura = 1;	// La primera componente (posici�n 0) es 
							// parte de la soluci�n, por eso se empieza
							// a escribir por la posici�n 1
	int pos_lectura;
	int pos_encontrado;

	// Empiezamos la lectura por la posici�n 1 (no es preciso empezar 
	// por la la posici�n 0 porque es parte de la soluci�n)

	for (pos_lectura=1; pos_lectura<total_utilizados_copia2; pos_lectura++) {

		int valor_buscado = copia2_datos[pos_lectura];
		
		// Busco "valor_buscado" (el de "pos_lectura") en el 
		// subvector izquierdo (posiciones: 0 hasta "pos_escritura"-1)

  		int pos = 0;
		bool encontrado = false;
    
		while ((pos < pos_escritura) && (!encontrado))

			if (copia2_datos[pos] == valor_buscado) 
				encontrado = true; //�xito: terminar
			else
				pos++; // Siguiente posici�n

 		if (!encontrado) {
		
			// Si no est�, lo copiamos en la posici�n indicada por 
			// "pos_escritura" y adelantamos la posici�n de escritura. 

			copia2_datos[pos_escritura] = copia2_datos[pos_lectura];
			pos_escritura++;
		}

	} // for pos_lectura

	total_utilizados_copia2 = pos_escritura; // actualizo el tama�o

 
	// Se muestran los datos del vector copia (2) despu�s de procesarlos 
	
 	cout << endl;	
	cout << "Copia 2 despu�s de eliminar repetidos con algoritmo eficiente"
	     << " (" << setw(3) << total_utilizados_copia2 << " datos):" << endl;

	for (int i=0; i<total_utilizados_copia2; i++) 
		cout << setw(3) << copia2_datos[i] << "  "; 
	cout << endl;
	
	
	return (0);
}
