/****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// (C) FRANCISCO JOS� CORTIJO BON
// (C) JUAN CARLOS CUBERO TALAVERA
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 3
// EJERCICIOS 26 y 27 
//
/*	
	Este programa gestiona las n�minas de los empleados de una empresa. 
	El c�mputo de la n�mina se realiza en base a los siguientes criterios:
	a)	Categor�as laborales: Operario, Base, Administrativo y Directivo.
	b)	El salario base depende de: 
		b-1) la antig�edad del trabajador, y 
		b-2) la categor�a laboral 
				Operario = 900 euros			Base = 1100 euros
				Administrativos = 1200 euros	Directivos = 2000 euros
		b-3) El salario base se incrementa con un tanto por ciento igual 
			 al n�mero de a�os trabajados.
	c)	Hay complementos en n�mina por el n�mero de horas extraordinarias. 
		c-1) La hora extra se paga: 
				Operario = 16 euros				Base = 23 euros
				Administrativos = 25 euros		Directivos = 30 euros
		c-2) A este complemento se le aplica una subida porcentual igual 
			 al n�mero de a�os trabajados.
*/
/****************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

/****************************************************************************/
// Tipo enumerado para las categorias laborales

enum EnumCategoriaLaboral {Operario, Base, Administrativo, Directivo};

//////////////////////////////////////////////////////////////////////////////
// Cada empleado, mensualmente, tendr� asociado un objeto de la clase 

class NominaEmpleado
{
private:

	EnumCategoriaLaboral categoria_laboral;	// Categoria
	
	// PRE: 0 <= anios_antiguedad <= 100
	int anios_antiguedad;			// a�os de antig�edad

	// PRE: horas_extraordinarias >= 0
	int horas_extraordinarias;		// horas extraordinarias

public:

	/************************************************************************/
	// Constructor con argumentos
	//
	// El constructor recibe como argumentos valores para los tres 
	// campos privados. Lo hacemos as� porque suponemos que en la empresa, 
	// la mayor parte de los trabajadores realizan horas extraordinarias. 
	// Si no fuera s�, podr�amos omitir el n�mero de horas extra como 
	// par�metro al constructor y asignar el dato miembro privado 
	// "horas_extraordinarias" a cero (en el constructor).
	// Posteriormente, no permitimos modificar la categor�a laboral ni 
	// la antig�edad, pero s� el n�mero de horas extraordinarias. 
	// 
	// Recibe: categoria_laboral_trabajador, la categor�a del trabajador.
	//		   anios_antiguedad_trabajador, a�os en la empresa.
	//		   horas_extraordinarias_trabajadas, horas extras trabajadas.
	// 
	// PRE: anios_antiguedad_trabajador >= 0
	// PRE: horas_extraordinarias_trabajadas >= 0

	NominaEmpleado (EnumCategoriaLaboral categoria_laboral_trabajador, 
				    int anios_antiguedad_trabajador, 
			 	    int horas_extraordinarias_trabajadas)
	{
		categoria_laboral = categoria_laboral_trabajador;
		anios_antiguedad = anios_antiguedad_trabajador;
		horas_extraordinarias = horas_extraordinarias_trabajadas;
	}

	/************************************************************************/
	// M�todo Set para el campo "horas_extraordinarias", el �nico
	// que puede modificarse una vez construido el objeto
	//
	// Recibe: horas_extras_trabajadas, n�mero de horas extra trabajadas.
	// PRE: horas_extras_trabajadas >= 0
	
	void SetHorasExtraordinarias (int horas_extras_trabajadas)
	{
		horas_extraordinarias = horas_extras_trabajadas;
	}

	/************************************************************************/
	// M�todos Get para la lectura de los campos privados
	
	EnumCategoriaLaboral GetCategoriaLaboral (void)
	{
		return (categoria_laboral);
	}
	
	int GetHorasExtraordinarias (void)
	{
		return (horas_extraordinarias);
	}

	/************************************************************************/
	// Calcula la parte de salario que corresponde al sueldo base m�s 
	// el incremento que le corresponde por a�os de antig�edad.

	double CuantiaBase (void)
	{
		double base;

		switch (categoria_laboral) {
			
			case (Operario) : 		base = 900;
									break;
			case (Base) : 			base = 1100;
									break;
			case (Administrativo) : base = 1200;
									break;
			case (Directivo) : 		base = 2000;
									break;
		}
		return (AplicaAumento (base, anios_antiguedad));
	}

	/************************************************************************/
	// Calcula la parte de salario que corresponde por horas extraordinarias 
	// y el incremento que le corresponde a esta parte por a�os de antig�edad.

	double ComplementoHorasExtraordinarias (void)
	{
		double cuantia_por_hora;

		switch (categoria_laboral) {
			
			case (Operario) : 		cuantia_por_hora = 16;
									break;
			case (Base) : 			cuantia_por_hora = 23;
									break;
			case (Administrativo) : cuantia_por_hora = 25;
									break;
			case (Directivo) : 		cuantia_por_hora = 30;
									break;
		}
		double total = cuantia_por_hora * horas_extraordinarias;
		return (AplicaAumento (total, anios_antiguedad));
	}

	/************************************************************************/
	// Calcula el sueldo actualizado sumando los dos componentes 

	double Total_a_Cobrar (void)
	{
		return (CuantiaBase() + ComplementoHorasExtraordinarias());
	}
	/************************************************************************/

private: 

	/************************************************************************/
	// Incrementa "valor" en el porcentaje indicado por "aumento_porcentual" 
	// y devuelve el valor incrementado 
	// 
	// Recibe: 	valor, la cantidad que sirve de base para el aumento.
	//			aumento_porcentual, el porcentaje que se va a incrementar.
	// PRE: 0 <= aumento_porcentual <= 100
	
	double AplicaAumento(double valor, double aumento_porcentual)
	{
		return (valor * (1 + (aumento_porcentual/100.0)));
	}

	/************************************************************************/
};

/////////////////////////////////////////////////////////////////////////////

/****************************************************************************/
/*
	En estos momentos, la funcionalidad de la clase "NominaEmpleado" est� 
	limitada porque no sabemos c�mo almacenar varios objetos de una clase en 
	una estructura de datos contenedora (por ejemplo, un vector). 
	Esto hace que cada empleado requiera un objeto espec�fico y se necesiten 
	tantos objetos "NominaEmpleado" como empleados haya en la empresa. 
	No es una soluci�n aceptable (pero es la �nica posible por ahora).  
	
	La funci�n main que se presenta a continuaci�n ser� muy simple: 
	1) Calcular� y mostrar� el salario de cada uno de los tipos de empleado 
	   (Operario, Base, Administrativo, Directivo) bajo las mismas condiciones 
	   de antig�edad y horas extraordinarias, para poder compararlos. 
	2) Calcular� cu�ntas horas extra debe trabajar un operario base para 
	   ganar lo mismo que un directivo. 
*/

int main()
{
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 

 	/************************************************************************  
	Calcular y mostrar el salario de cada uno de los tipos de empleado 
	(Operario, Base, Administrativo, Directivo) bajo las mismas condiciones.
	************************************************************************/  

	int anios_antiguedad = 5;  	// Aseguramos que se cumple la precondic�n
	int horas_extras = 10;  	// Aseguramos que se cumple la precondic�n
 
	// Creaci�n de los objetos NominaEmpleado --> constructor
  
	NominaEmpleado nomina_operario  (Operario, anios_antiguedad, horas_extras);
	NominaEmpleado nomina_base (Base, anios_antiguedad, horas_extras);
	NominaEmpleado nomina_administrativo (Administrativo, 
										        anios_antiguedad, horas_extras);
	NominaEmpleado nomina_directivo (Directivo, anios_antiguedad, horas_extras);
		
	// Calculo del salario tras los incrementos por antig�edad y por 
	// horas trabajadas: act�a el m�todo "Total_a_Cobrar"

	cout << endl;
	cout << "Salarios con antig�edad = " << anios_antiguedad << " a�os y " 
		 << horas_extras << " horas extraordinarias" << endl;
	cout << "\tSalario del operario:       " << setw(10) << setprecision(2) 
		 << nomina_operario.Total_a_Cobrar() << endl;
	cout << "\tSalario del puesto base:    " << setw(10) << setprecision(2) 
		 << nomina_base.Total_a_Cobrar() << endl;
	cout << "\tSalario del administrativo: " << setw(10) << setprecision(2) 
		 << nomina_administrativo.Total_a_Cobrar() << endl;	 
	cout << "\tSalario del directivo:      " << setw(10) << setprecision(2) 
		 << nomina_directivo.Total_a_Cobrar() << endl;
 
	return (0);
}
