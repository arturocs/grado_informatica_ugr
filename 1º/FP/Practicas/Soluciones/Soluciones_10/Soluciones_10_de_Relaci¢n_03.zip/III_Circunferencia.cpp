/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 3
// EJERCICIO 30
//
/*	
	Las coordenadas de un punto en un espacio 2D se representan mediante 
	un struct "CoordenadasPunto2D". 
	Se construye la clase "Circunferencia" caracterizada por: 
		1) centro (CoordenadasPunto2D)
		2) radio  (double) 
	Se ofrecen m�todos p�blicos para:  	
		1) Calcular la longitud de la circunferencia
		2) Calcular el �rea del c�rculo interior
		3) Calcular si la circunferencia contiene a un punto dado. 
		4) Consultar los valores del centro y el radio.

	Observaciones de dise�o: 
		1) El valor de PI debe ser constante, y el mismo para todos los 
		objetos de la clase Circunferencia --> constante est�tica.
		2) No vamos a permitir la modificaci�n de los campos de la clase, 
		por lo que no ofreceremos m�todos Set para cambiar estos valores. 
		Una vez fijados por el constructor no se van a poder cambiar.
*/

/***************************************************************************/

#include <iostream>
#include <cctype>
#include <cmath>
#include <iomanip>
using namespace std;

/***************************************************************************/
// Tipo struct para los puntos 2D

struct CoordenadasPunto2D 
{
	double x;	//                             2
	double y;	// Coordenadas de un punto en R   (espacio 2D)
};

/////////////////////////////////////////////////////////////////////////////
// La clase "Circunferencia" representa circunferencias, objetos geom�tricos 
// que verifican la propiedad de que los puntos (x,y) que la forman est�n a 
// la misma distancia de otro punto llamado centro. 

class Circunferencia
{

private:

	// La constante "PI" es com�n a todos los objetos de la clase.
	// Como no es int no puede iniciarse junto a su declaraci�n. 
	static const double PI;		
	
	// Centro de la circunferencia
	CoordenadasPunto2D centro;	
	
	// Longitud del radio
	// PRE: radio >= 0
	double radio;
	
public:

	/***********************************************************************/
	// Constructor con argumentos
	// Recibe:
	//		el_centro, un struct con las coordenadas del centro
	//		radio, el valor del radio
	// PRE: radio >= 0

	Circunferencia (CoordenadasPunto2D el_centro, double el_radio)
	{
		centro = el_centro;
		radio  = el_radio; 
	}

	/***********************************************************************/
	// M�todos Get
	
	CoordenadasPunto2D GetCentro (void)
	{
		return (centro);
	}

	double GetRadio (void)
	{
		return (radio);
	}

	/***********************************************************************/
	// Calcula la longitud de la circunferencia

	double Longitud (void)
	{
		return (2.0 * PI * radio);
	}

	/***********************************************************************/
	// Calcula el �rea del c�rculo
	
	double Area (void)
	{
		return (PI * radio * radio);
	}

	/***********************************************************************/
	// Calcular si la circunferencia contiene a un punto dado.
	/*
		Un punto (p_x, p_y) est� dentro de una circunferencia con centro 
		(c_x, c_y) y radio r si se verifica que:

		(p_x - c_x)^2 + (p_y - c_y)^2  <=  r^2
	*/

	bool Contiene (CoordenadasPunto2D un_punto)
	{
		double dif_x = pow (centro.x - un_punto.x, 2);
		double dif_y = pow (centro.y - un_punto.y, 2);

		return (dif_x + dif_y <= radio*radio);
	}

	/***********************************************************************/

};

// Inicializaci�n de la constante est�tica PI

const double Circunferencia::PI = 3.1415926;


/////////////////////////////////////////////////////////////////////////////

/***************************************************************************/

int main()
{	
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 

	// Lectura de datos
	
	double centro_x, centro_y;

	cout << "Coordenada X del centro = ";
	cin >> centro_x; 

	cout << "Coordenada Y del centro = ";
	cin >> centro_y; 

	// Lectura del radio y filtro para asegurar la precondici�n
	
	double un_radio; 

	do {
		cout << "Introduzca el radio = ";
		cin >> un_radio; 
	} while (un_radio < 0);

	// Crea un dato "CoordenadasPunto2D" y rellena los campos del struct 
	// con los valores leidos para poder pasarlo al constructor.

	CoordenadasPunto2D un_centro;
	un_centro.x = centro_x;
	un_centro.y = centro_y;

	// Creaci�n de un objeto Circunferencia --> constructor

	Circunferencia mi_circunferencia (un_centro, un_radio);

	// Uso de los m�todos Get

	CoordenadasPunto2D el_centro = mi_circunferencia.GetCentro(); 

	cout << endl; 
	cout << "Circunferencia centrada en (" << setw(6) << setprecision(2) 
		 << el_centro.x << ", " << setw(6) <<setprecision(2) 
		 << el_centro.y << ") y radio " << setw(6) << setprecision(2) 
		 << mi_circunferencia.GetRadio() << endl;

	// Uso de los m�todos de c�lculo sencillos

	cout << "\nLongitud de la circunferencia = " 
		<< setw(6) << setprecision(2) << mi_circunferencia.Longitud();
	cout << "\nArea del circulo = " 
		<< setw(6) << setprecision(2) << mi_circunferencia.Area();

	// C�lculo de la pertenencia (o no) de una serie de puntos.

	bool sigo = true; 

	while (sigo) {
	
		double punto_x, punto_y;

		cout << endl << endl;
		cout << "Comprobaci�n de la pertenencia de un punto al c�rculo." << endl;

		cout << "\tCoordenada X del punto = ";
		cin >> punto_x; 
		cout << "\tCoordenada Y del punto = ";
		cin >> punto_y; 

		// Crea un dato CoordenadasPunto2D y rellena los campos del struct 
		// con los valores leidos, para poder pasarlo al m�todo Contiene()

		CoordenadasPunto2D un_punto;
		un_punto.x = punto_x;
		un_punto.y = punto_y;

		if (mi_circunferencia.Contiene(un_punto)) 
			cout << "\tEl punto SI est� contenido en la circunferencia" << endl;
		else 
			cout << "\tEl punto NO est� contenido en la circunferencia" << endl;
		cout << endl; 
		
		// Preparando una nueva comprobaci�n

		char respuesta;
		cout << "\t�Desea un nuevo test (s/n) ? --> "; 
		
		cin >> respuesta; 
		if (toupper(respuesta) != 'S') 
			sigo = false; 
	
	} // while (sigo)

	cout << endl << endl;
	
	return (0);
}
